"""Exact exploratory Jacobian of the three squared period lengths."""
import sympy as s
import argparse,time
from pathlib import Path
from fractions import Fraction as F
from direct_face_12_certificate import ref


def run(delta,output):
    cc,vv=ref(F(delta));x,y,z=s.symbols('x y z');fs=s.Matrix([x,y,z]);C=list(map(s.Rational,cc))
    Q=x*y+x*z+y*z;t=x*y*z/Q
    K=(s.diag(*C)-2*t*s.eye(3)+t*s.ones(3)-3*t/Q*fs*fs.T).applyfunc(s.cancel)
    start=time.monotonic();Ki=K.inv(method='DM');vv=vv+[[vv[0][i]-vv[1][i] for i in range(3)]]
    R=[s.cancel(sum(a*a for a in Ki*s.Matrix(list(map(s.Rational,v))))) for v in vv]
    print('norms ready',time.monotonic()-start,flush=True)
    J=s.Matrix([[s.cancel(s.diff(r,c)) for c in (x,y,z)] for r in R]);print('Jac ready',time.monotonic()-start,flush=True)
    Jnums=[];dens=[]
    for row in J.tolist():
        d=s.lcm([s.denom(v) for v in row]);dens.append(d);Jnums.append([s.cancel(v*d) for v in row])
    print('poly ready',time.monotonic()-start,flush=True)
    polynomials=[[s.Poly(v,x,y,z,domain=s.QQ) for v in row] for row in Jnums]
    factors=[]
    for i,row in enumerate(polynomials):
        g=s.polys.polytools.terms_gcd(s.gcd(s.gcd(row[0],row[1]),row[2])).as_expr()
        gp=s.Poly(g,x,y,z,domain=s.QQ);factors.append(g)
        polynomials[i]=[v.exquo(gp) for v in row]
    a,b,c=polynomials[0];d,e,f=polynomials[1];g,h,i=polynomials[2]
    num=(a*(e*i-f*h)-b*(d*i-f*g)+c*(d*h-e*g)).as_expr()
    print('det ready',time.monotonic()-start,flush=True)
    print('row factors',factors,flush=True)
    fact=s.factor(num);Path(output).write_text(str(fact)+'\n')
    print('factorization:',str(fact),flush=True);print('seconds',time.monotonic()-start)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--delta',required=True);p.add_argument('--output',required=True)
    a=p.parse_args();run(a.delta,a.output)
