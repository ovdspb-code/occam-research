"""Global stationarity test with rigorous dual-vector lower bounds.
Floating-point solves choose arbitrary support vectors only; the inequalities
are certified afresh by outward arithmetic. An unfinished queue is no proof.
"""
import argparse,hashlib,json,math,time
from pathlib import Path
from fractions import Fraction as F
import numpy as np
import interior_stationarity_certificate as core
from direct_face_12_certificate import I,ref


def pretest(box,C,vs,budget,target,dirlow):
    fs=[I(*box[i])*C[i] for i in range(3)];x,y,z=fs
    # Exact analytic diagonal-domination lower bound.
    small=min(f.b for f in fs)
    elementary=I(dirlow)/(I(1)+4*I(small)/C[0])
    if elementary.a>target:return 'elementary'
    M=sum(C)+x+y+z+x*y/z+x*z/y+y*z/x
    if M.a>budget:return 'material'
    Q=x*y+x*z+y*z;t=x*y*z/Q
    K=[[((C[i] if i==j else I(0))-2*t*(i==j)+t-3*t*fs[i]*fs[j]/Q) for j in range(3)] for i in range(3)]
    mid=np.array([[(v.a+v.b)/2 for v in row] for row in K])
    total=I(0)
    for v in vs:
        vm=np.array([(a.a+a.b)/2 for a in v])
        try:p=np.linalg.solve(mid,np.linalg.solve(mid,vm))
        except np.linalg.LinAlgError:return None
        if not np.all(np.isfinite(p)):return None
        # p is now a fixed binary vector: no numerical inverse is trusted.
        num=sum((I(p[i])*v[i] for i in range(3)),I(0))
        den=sum((sum((row[j]*I(p[j]) for j in range(3)),I(0)).square() for row in K),I(0)).sqrt()
        if den.b<=0:return None
        abslow=max(0,num.a,-num.b)
        total+=I(abslow)/I(den.b)
    if total.a>target:return 'support'
    return None


def run(a):
    cc,vv=ref(F(a.delta));assert F(a.delta)==F(1,100)
    vv=vv+[[vv[0][i]-vv[1][i] for i in range(3)]]
    C=[I.rat(x) for x in cc];vs=[[I.rat(x) for x in v] for v in vv]
    dirlow=sum((sum(((v[i]/C[i]).square() for i in range(3)),I(0)).sqrt() for v in vs),I(0)).a
    target=I.rat(a.target);budget=I.rat(a.budget)
    assert F(7,2)/F(51,50)>F(a.target)
    floors=[I.rat(cc[0]/(200*x)).a for x in cc]
    queue=[tuple((x,1.) for x in floors)];start=time.monotonic();n=0;unresolved=None
    counts={k:0 for k in ['symmetry','elementary','material','support','length','gradient']}
    while queue and n<a.max_boxes and time.monotonic()-start<a.wall_seconds:
        box=queue.pop();n+=1
        if box[1][1]<box[2][0]:counts['symmetry']+=1;continue
        try:
            reason=pretest(box,C,vs,budget.b,target.b,dirlow)
            if reason:counts[reason]+=1;continue
            mass,L=core.assess(box,C,vs)
            if mass.a>budget.b:counts['material']+=1;continue
            if L is not None:
                if L.v.a>target.b:counts['length']+=1;continue
                if any(g.a>0 or g.b<0 for g in L.g):counts['gradient']+=1;continue
        except (ZeroDivisionError,ValueError,OverflowError):pass
        axis=max(range(3),key=lambda i:box[i][1]-box[i][0]);lo,hi=box[axis];mid=(lo+hi)/2
        if mid==lo or mid==hi:unresolved=box;break
        l=list(box);r=list(box);l[axis]=(lo,mid);r[axis]=(mid,hi);queue.extend([tuple(r),tuple(l)])
    out={'certified':not queue and unresolved is None,'budget':a.budget,'target':a.target,'processed':n,
         'pruned':counts,'pending':len(queue),'pending_next':queue[-1] if queue else None,'unresolved':unresolved,
         'elapsed_seconds':time.monotonic()-start,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    Path(a.output).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--delta',required=True);p.add_argument('--budget',required=True);p.add_argument('--target',required=True)
    p.add_argument('--max-boxes',type=int,required=True);p.add_argument('--wall-seconds',type=float,required=True)
    p.add_argument('--output',required=True);run(p.parse_args())
