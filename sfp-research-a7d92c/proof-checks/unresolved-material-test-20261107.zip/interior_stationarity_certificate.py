"""Outward interval exclusion of competitive interior stationary points.
This is a certificate only if the entire queue is exhausted. Fixed delta=1/100
is supplied as a parameter; the analytically justified min(f)>Cmin/200 floor
is checked against the declared length upper bound before use.
"""
import argparse, hashlib, json, math, time
from fractions import Fraction as F
from pathlib import Path
from direct_face_12_certificate import I, ref


class D:
    __slots__=('v','g')
    def __init__(self,v,g=None):
        self.v=v if isinstance(v,I) else I(v)
        self.g=(I(0),I(0)) if g is None else g
    def __add__(self,o):
        o=dual(o); return D(self.v+o.v,tuple(a+b for a,b in zip(self.g,o.g)))
    __radd__=__add__
    def __neg__(self): return D(-self.v,tuple(-a for a in self.g))
    def __sub__(self,o): return self+-dual(o)
    def __rsub__(self,o): return dual(o)+-self
    def __mul__(self,o):
        o=dual(o);return D(self.v*o.v,tuple(a*o.v+self.v*b for a,b in zip(self.g,o.g)))
    __rmul__=__mul__
    def __truediv__(self,o):
        o=dual(o);v=self.v/o.v
        return D(v,tuple((a-v*b)/o.v for a,b in zip(self.g,o.g)))
    def square(self): return D(self.v.square(),tuple(2*self.v*a for a in self.g))
    def sqrt(self):
        v=self.v.sqrt();return D(v,tuple(a/(2*v) for a in self.g))


def dual(v):return v if isinstance(v,D) else D(v)


def assess(box,C,vs):
    rs=[D(I(*box[i]), (I(1),I(0)) if i==0 else (I(0),I(1))) for i in range(3)]
    x,y,z=[rs[i]*C[i] for i in range(3)]
    mass=D(sum(C))+x+y+z+x*y/z+x*z/y+y*z/x
    Q=x*y+x*z+y*z;t=x*y*z/Q
    fs=[x,y,z]
    K=[[D(C[i] if i==j else I(0))-2*t*(i==j)+t-3*t*fs[i]*fs[j]/Q for j in range(3)] for i in range(3)]
    a,b,c=K[0];_,d,e=K[1];_,_,f=K[2]
    aa=d*f-e.square();ab=c*e-b*f;ac=b*e-c*d
    dd=a*f-c.square();de=b*c-a*e;ff=a*d-b.square()
    det=a*aa+b*ab+c*ac
    if det.v.a<=0: return mass.v,None
    inv=[[aa,ab,ac],[ab,dd,de],[ac,de,ff]]
    total=D(0)
    for v in vs:
        u=[sum((row[j]*v[j] for j in range(3)),D(0))/det for row in inv]
        total+=sum((a.square() for a in u),D(0)).sqrt()
    return mass.v,total


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--delta',required=True);p.add_argument('--budget',required=True)
    p.add_argument('--target',required=True);p.add_argument('--max-boxes',type=int,required=True)
    p.add_argument('--wall-seconds',type=float,required=True);p.add_argument('--output',required=True)
    a=p.parse_args();delta=F(a.delta);cc,vv=ref(delta)
    assert delta==F(1,100)
    target=I.rat(a.target); budget=I.rat(a.budget)
    # Accepted analytic ell_dir>7/2. At min(f)<=Cmin/200,
    # ell>=ell_dir/(1+4/200)>target. No imposed physical guard.
    assert F(7,2)/F(51,50)>F(a.target)
    vv=vv+[[vv[0][i]-vv[1][i] for i in range(3)]]
    C=[I.rat(x) for x in cc];vs=[[I.rat(x) for x in v] for v in vv]
    floors=[I.rat(cc[0]/(200*x)).a for x in cc]
    initial=tuple((x,1.) for x in floors);queue=[initial]
    processed=0;pruned={'material':0,'symmetry':0,'length':0,'gradient':0};start=time.monotonic()
    unresolved=None
    while queue and processed<a.max_boxes and time.monotonic()-start<a.wall_seconds:
        box=queue.pop();processed+=1
        if box[1][1]<box[2][0]:pruned['symmetry']+=1;continue
        try:
            mass,L=assess(box,C,vs)
            if mass.a>budget.b:pruned['material']+=1;continue
            if L is not None:
                if L.v.a>target.b:pruned['length']+=1;continue
                if any(g.a>0 or g.b<0 for g in L.g):pruned['gradient']+=1;continue
        except (ZeroDivisionError,ValueError,OverflowError):pass
        axis=max(range(3),key=lambda i:box[i][1]-box[i][0]);lo,hi=box[axis];mid=(lo+hi)/2
        if mid==lo or mid==hi:unresolved=box;break
        l=list(box);r=list(box);l[axis]=(lo,mid);r[axis]=(mid,hi)
        queue.extend([tuple(r),tuple(l)])
    out={'certified':not queue and unresolved is None,'budget':a.budget,'target':a.target,
         'processed':processed,'pruned':pruned,'pending':len(queue),'unresolved':unresolved,
         'pending_next':queue[-1] if queue else None,'elapsed_seconds':time.monotonic()-start,
         'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    Path(a.output).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))


if __name__=='__main__':main()
