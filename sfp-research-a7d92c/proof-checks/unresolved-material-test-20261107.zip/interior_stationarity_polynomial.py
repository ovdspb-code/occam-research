"""Exact cancellation before interval differentiation; same global box contract."""
import argparse, hashlib, json, math, time
from pathlib import Path
from fractions import Fraction as F
import sympy as sp
import interior_stationarity_certificate as core
from direct_face_12_certificate import I, ref


def tree(poly,variables):
    if not variables:return I.rat(F(str(poly)))
    P=sp.Poly(poly,variables[0]);degree=P.degree()
    if degree is sp.S.NegativeInfinity:return [I(0)]
    return [tree(P.nth(i),variables[1:]) for i in range(int(degree),-1,-1)]


def ev(T,rs):
    if isinstance(T,I):return core.D(T)
    value=core.D(0)
    for child in T:value=value*rs[0]+ev(child,rs[1:])
    return value


def build(delta):
    cc,vv=ref(delta);x,y,z=sp.symbols('x y z');rs=(x,y,z)
    cs=list(map(sp.Rational,cc));fs=sp.Matrix([cs[i]*rs[i] for i in range(3)])
    Q=fs[0]*fs[1]+fs[0]*fs[2]+fs[1]*fs[2];t=sp.prod(fs)/Q
    K=sp.diag(*cs)-2*t*sp.eye(3)+t*sp.ones(3)-3*t/Q*(fs*fs.T)
    K=K.applyfunc(sp.cancel)
    inv=K.inv(method='DM')
    vv=vv+[[vv[0][i]-vv[1][i] for i in range(3)]]
    data=[]
    for v in vv:
        w=inv*sp.Matrix(list(map(sp.Rational,v)))
        norm=sp.cancel(sum(a*a for a in w))
        numerator,denominator=sp.fraction(norm)
        data.append((tree(numerator,rs),tree(denominator,rs)))
    return cs,data


def run(a):
    start=time.monotonic();delta=F(a.delta);cc,data=build(delta)
    generation=time.monotonic()-start
    C=[I.rat(F(str(v))) for v in cc];budget=I.rat(a.budget);target=I.rat(a.target)
    assert delta==F(1,100) and F(7,2)/F(51,50)>F(a.target)
    floors=[I.rat(F(str(cc[0]/(200*x)))).a for x in cc]
    queue=[tuple((x,1.) for x in floors)];pruned={'material':0,'symmetry':0,'length':0,'gradient':0}
    n=0;unresolved=None;start=time.monotonic()
    while queue and n<a.max_boxes and time.monotonic()-start<a.wall_seconds:
        box=queue.pop();n+=1
        if box[1][1]<box[2][0]:pruned['symmetry']+=1;continue
        try:
            rs=[core.D(I(*box[i]),(I(1),I(0)) if i==0 else (I(0),I(1))) for i in range(3)]
            x,y,z=[rs[i]*C[i] for i in range(3)]
            M=core.D(sum(C))+x+y+z+x*y/z+x*z/y+y*z/x
            if M.v.a>budget.b:pruned['material']+=1;continue
            L=sum(((ev(num,rs)/ev(den,rs)).sqrt() for num,den in data),core.D(0))
            if L.v.a>target.b:pruned['length']+=1;continue
            if any(g.a>0 or g.b<0 for g in L.g):pruned['gradient']+=1;continue
        except (ZeroDivisionError,ValueError,OverflowError):pass
        axis=max(range(3),key=lambda i:box[i][1]-box[i][0]);lo,hi=box[axis];mid=(lo+hi)/2
        if mid==lo or mid==hi:unresolved=box;break
        l=list(box);r=list(box);l[axis]=(lo,mid);r[axis]=(mid,hi);queue.extend([tuple(r),tuple(l)])
    out={'certified':not queue and unresolved is None,'budget':a.budget,'target':a.target,'processed':n,
         'pruned':pruned,'pending':len(queue),'unresolved':unresolved,'pending_next':queue[-1] if queue else None,
         'generation_seconds':generation,'elapsed_seconds':time.monotonic()-start,
         'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    Path(a.output).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--delta',required=True);p.add_argument('--budget',required=True);p.add_argument('--target',required=True)
    p.add_argument('--max-boxes',type=int,required=True);p.add_argument('--wall-seconds',type=float,required=True)
    p.add_argument('--output',required=True);run(p.parse_args())
